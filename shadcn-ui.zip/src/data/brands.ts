import { Brand } from "@/types";

export const brands: Brand[] = [
  {
    id: "classic",
    name: "Classic",
    description: "ملابس كلاسيكية أنيقة تناسب جميع المناسبات",
    instagramLink: "https://www.instagram.com/classic",
    image: "/assets/brands/classic.jpg"
  },
  {
    id: "ghyma",
    name: "Ghyma",
    description: "تصاميم عصرية تجمع بين الأناقة والراحة",
    instagramLink: "https://www.instagram.com/ghyma",
    image: "/assets/brands/ghyma.jpg"
  },
  {
    id: "designerr-mix",
    name: "Designerr. Mix",
    description: "قطع فاخرة مصممة حسب أحدث صيحات الموضة",
    instagramLink: "https://www.instagram.com/designerr.mix",
    image: "/assets/brands/designerr-mix.jpg"
  }
];